#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 tint;

void main() {
	vec4 color = texture2D(texture, texcoord) * tint;
	
	if (color.a < 0.01) discard;

/* DRAWBUFFERS:04 */
	gl_FragData[0] = color; //gcolor
	gl_FragData[1] = vec4(1.0); //gaux1
}